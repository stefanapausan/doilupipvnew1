<?php

/**
 * @file
 * Generic transliteration data for the PhpTransliteration class.
 */

$base = [
  0x00 => 'zhi', 'liu', 'mei', 'li', 'rong', 'zha', 'zao', 'biao', 'zhan', 'zhi', 'long', 'dong', 'lu', 'sheng', 'li', 'lan',
  0x10 => 'yong', 'shu', 'xun', 'shuan', 'qi', 'zhen', 'qi', 'li', 'yi', 'xiang', 'zhen', 'li', 'se', 'gua', 'kan', 'ben',
  0x20 => 'ren', 'xiao', 'bai', 'ren', 'bing', 'zi', 'chou', 'yi', 'ci', 'xu', 'zhu', 'jian', 'zui', 'er', 'er', 'you',
  0x30 => 'fa', 'gong', 'kao', 'lao', 'zhan', 'lie', 'yin', 'yang', 'he', 'gen', 'yi', 'shi', 'ge', 'zai', 'luan', 'fu',
  0x40 => 'jie', 'heng', 'gui', 'tao', 'guang', 'wei', 'kuang', 'ru', 'an', 'an', 'juan', 'yi', 'zhuo', 'ku', 'zhi', 'qiong',
  0x50 => 'tong', 'sang', 'sang', 'huan', 'ju', 'jiu', 'xue', 'duo', 'zhui', 'yu', 'zan', 'Kasei ', 'ying', 'jie', 'liu', 'zhan',
  0x60 => 'ya', 'rao', 'zhen', 'dang', 'qi', 'qiao', 'hua', 'gui', 'jiang', 'zhuang', 'xun', 'suo', 'sha', 'zhen', 'bei', 'ting',
  0x70 => 'kuo', 'jing', 'po', 'ben', 'fu', 'rui', 'tong', 'jue', 'xi', 'lang', 'liu', 'feng', 'qi', 'wen', 'jun', 'gan',
  0x80 => 'su', 'liang', 'qiu', 'ting', 'you', 'mei', 'bang', 'long', 'peng', 'zhuang', 'di', 'xuan', 'tu', 'zao', 'ao', 'gu',
  0x90 => 'bi', 'di', 'han', 'zi', 'zhi', 'ren', 'bei', 'geng', 'jian', 'huan', 'wan', 'nuo', 'jia', 'tiao', 'ji', 'xiao',
  0xA0 => 'lu', 'hun', 'shao', 'cen', 'fen', 'song', 'meng', 'wu', 'li', 'li', 'dou', 'qin', 'ying', 'suo', 'ju', 'ti',
  0xB0 => 'xie', 'kun', 'zhuo', 'shu', 'chan', 'fan', 'wei', 'jing', 'li', 'bin', 'xia', 'fo', 'tao', 'zhi', 'lai', 'lian',
  0xC0 => 'jian', 'zhuo', 'ling', 'li', 'qi', 'bing', 'lun', 'cong', 'qian', 'mian', 'qi', 'qi', 'cai', 'gun', 'chan', 'de',
  0xD0 => 'fei', 'pai', 'bang', 'bang', 'hun', 'zong', 'cheng', 'zao', 'ji', 'li', 'peng', 'yu', 'yu', 'gu', 'jun', 'dong',
  0xE0 => 'tang', 'gang', 'wang', 'di', 'cuo', 'fan', 'cheng', 'zhan', 'qi', 'yuan', 'yan', 'yu', 'quan', 'yi', 'sen', 'ren',
  0xF0 => 'chui', 'leng', 'qi', 'zhuo', 'fu', 'ke', 'lai', 'zou', 'zou', 'zhao', 'guan', 'fen', 'fen', 'shen', 'qing', 'ni',
];
